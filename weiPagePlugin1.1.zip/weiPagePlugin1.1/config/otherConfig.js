	$(function(){
		//富文本编辑器配置
//		UE.Editor.prototype._bkGetActionUrl = UE.Editor.prototype.getActionUrl;
//	    UE.Editor.prototype.getActionUrl = function(action) {
//	                if (action == 'uploadimage' || action == 'uploadscrawl' || action == 'uploadimage') {
//	                    return '/uEditor/pic/upload';
//	                } else if (action == 'uploadvideo') {
//	                    return '/uEditor/pic/upload';
//	                } else {
//	                    return this._bkGetActionUrl.call(this, action);
//	                }
//	    };
	    
//	    function initEditor () {
//	    		var uE = UE.getEditor('edit_RTE');
//	    		uE.addListener("contentChange",function(){
//	    			var rteText = this.getContent();
//	    			rteText = rteText.replace(/["]/g,"'");
//	    			weiPageAction.editSelectPlugIn("txtHtml",rteText);
//	    		});
//	    }
//	    initEditor();	    
	});